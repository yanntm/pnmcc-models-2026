The vector oracles of the total examinations
============================================

Files: <model>-QLA.out (QuasiLivenessAll, one object per transition),
<model>-SMA.out (StableMarkingAll) and <model>-UBA.out (UpperBoundsAll, one
object per place). Format: the header line, the keyword a tool prints in
place of FORMULA (QLIVE, STABLE, BOUND), then the vector in definition order
of model.pnml, wrapped at 80 columns -- one character T/F/? per object for
QLIVE and STABLE, one token (an integer, inf or ?) per place for BOUND.
Object counts come from model.pnml, coloured instances are skipped.

Provenance, and what these values are worth
-------------------------------------------

Like the StateSpace oracles of oracleSS.tar.gz, these are answers the contest
did not give. They are weaker than those: the StateSpace values come from the
logs of the category's gold medallist, while these come from our own runs
only. Nothing independent has confirmed the objects our tools alone settled.

They are NOT contest results. The contest publishes no consensus for the
total examinations, so every object started as `?`. The values here come from
our own experiments, run with ITS-Tools and the projects around it, and from
the contest consensus of the ordinary examinations where that consensus pins
a whole vector. Treat them as a regression oracle: a value is what our tools
answered and agreed on, not an independently established truth.

What was checked before publishing
----------------------------------

* Two independent campaigns were merged object by object. Where both had
  answered, they agreed everywhere: 0 disagreements over 29.5 million
  objects.
* Against the contest consensus of the ordinary examinations, which decides
  the vectors one bit at a time: 1497 QuasiLiveness and 1604 StableMarking
  verdicts confirmed, 23281 upper bounds confirmed, no contradiction.
* Against our own answers to those same ordinary examinations, the same
  question asked two ways: 1499 QuasiLiveness, 1588 StableMarking and 1504
  OneSafe verdicts confirmed by their own vectors, no contradiction.
* Vectors a one-bit answer pins were completed from the contest consensus
  (QuasiLiveness TRUE makes a QLA vector all T, StableMarking FALSE makes an
  SMA vector all F); nothing already answered was overwritten and no
  completion disagreed with what was there.

Coverage
--------

  QLA  10 987 048 of 19 876 211 objects known (55.3%), plus 70 603 completed
  SMA   4 418 622 of  4 801 442 objects known (92.0%), plus 262 completed
  UBA   2 733 363 of  4 801 442 objects known (56.9%)

The tools: log2oracle.py, mergeoracles.py, totalagree.py and totalcheck.py /
ubacheck.py in PetriSpot's Petri/test/mcc, merge_total_oracles.py and
totalcomplete.py here.
